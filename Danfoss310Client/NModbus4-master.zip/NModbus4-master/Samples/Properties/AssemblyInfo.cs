using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MySample")]
[assembly: AssemblyProduct("NModbus")]
[assembly: AssemblyCopyright("Licensed under MIT License.")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: Guid("f2ba4cc2-ad31-4492-bfbf-377b50b9cbf2")]
[assembly: AssemblyVersion("1.11.0.0")]
[assembly: AssemblyFileVersion("1.11.0.0")]